#!/usr/bin/env python3
import os
import subprocess
import sys
import time

SERIAL = "/tmp/mich_core_serial.log"
WANT = "Mich Core 2.1: no modules, idling"


def main():
    if os.path.exists(SERIAL):
        os.remove(SERIAL)
    proc = subprocess.Popen(
        ["qemu-system-i386",
         "-drive", "file=disk.img,format=raw,if=ide,index=0,media=disk",
         "-boot", "c",
         "-serial", "file:" + SERIAL,
         "-display", "none",
         "-m", "128"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL)
    log = ""
    ok = False
    for _ in range(90):
        time.sleep(1)
        try:
            with open(SERIAL) as f:
                log = f.read()
        except FileNotFoundError:
            log = ""
        if WANT in log:
            ok = True
            break
        if "PANIC" in log or "DOUBLE FAULT" in log:
            break
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
    if not ok:
        print("TEST FAIL: banner not seen")
        print(log)
        sys.exit(1)
    if "PANIC" in log or "DOUBLE FAULT" in log:
        print("TEST FAIL: kernel panicked")
        print(log)
        sys.exit(1)
    print("BOOT TEST PASSED")


main()
