# Mich Core 2.1 — архитектура ядра

Этот документ = общий язык проекта. Код исповедует правило **ноль комментариев**;
всё "что это и как устроено" живёт здесь и в PLAN.md.

## Загрузка: только bigdevboot (BDBX)

GRUB/multiboot из ядра вымыт полностью (core 2.0+). Ядро грузится нашим
загрузчиком bigdevboot: stage1 (сектор 0) -> stage2 -> blob @LBA32 (kflat-ядро
+ модули), PM32, вход по entry из ELF.

Контракт (src/bootinfo.h): EAX = BD_MAGIC 0x58424442, EBX -> bd_info:
это e820-карта, framebuffer (addr/pitch/w/h/bpp), таблица bd_module
{start, end, cmdline}. Ядро при неверной магии печатает и встаёт:
других загрузчиков для Mich больше не существует.

src/bdb1.asm, src/bdb2.asm — бинарно общие с деревом MichOS.
mkboot.py собирает disk.img: boot-зона 256 блоков, без файловой системы
(соло-ядру FS не нужна, модулей 0).

## Карта памяти

- 0 .. 16 MB: ядро, identity + BSS; юзеру запрещено (USER_PD_INDEX_START = 4)
- 0x01000000 (16MB) .. 0x80000000 (2GB): юзер-область (USER_VA_MIN/MAX в paging.h)
- >= 0x80000000: ядро, шарится в каждый user PD (записи PD >= 512 копируются
  из ядерного PD при paging_create_user_directory)
- 0x90000000 / 0x90001000: scratch-окна paging_kmap_a/b — временное отображение
  ЛЮБОЙ физстраницы в ядро. Инструмент всех межпространственных операций.
- Стек юзер-процесса: 0x1080000 (одна страница), аргументы exec по +3584 (EXEC_ARGS_OFF)
- PMM: биткарта 0x4000 байт (= 512 MB max), low-пул < 16MB для PD/PT/ядерных стеков

## Задачи и pid

Пул 16 слотов, struct task в task.h. Состояния: RUNNING, BLOCKED_SEND,
BLOCKED_RECV, BLOCKED_WAIT, ZOMBIE, FREE.

**pid = (generation << 16) | slot**. Серверы первого поколения имеют pid == slot
(1..5: kbd/ata/pci/fs/init). При смерти слота поколение ++ -> старые хендлы
(wait/expect/kill/владелец IRQ) целятся мимо: ABA закрыта (API проверяет и slot,
и gen). Свежие процессы после переиспользования слота получают pids вида 0x1NNNN —
это нормально, они уникальны.

Кадр возврата в ring3: 52 байта на вершине ядерного стека = pusha[8] +
iret-кадр[5]. Имена: KFR_EDI..KFR_USS (task.h), сегменты USER_CS 0x1B /
USER_SS 0x23, USER_EFLAGS 0x202. fork копирует кадр dword'ами и зануляет
KFR_EAX (поэтому у ребёнка fork() == 0). exec переписывает кадр целиком:
EIP = entry ELF, EBX = указатель на argv-область (+3584 юзер-стека) или 0.

## Планировщик

Преемптивный round-robin, PIT 100 Гц, равный квант всем, O(n) скан по кругу.
CR3 перезаряжается ТОЛЬКО при смене page directory (core 2.0+, экономим TLB flush
на каждом тике). Переключение: ESP задачи + TSS esp0 + IOPB (iomap) + CR3.

## Пейджинг и kmap

Каждая задача владеет своим PD (страница из low-пула). paging_map_user пишет
PTE с USER|RW. paging_user_phys — обход PD->PT через kmap-окна: возвращает
физадрес только для PRESENT|USER страниц. Клонирование (fork) — поблочное,
dword'ами; освобождение — paging_free_user_pages.

**Контракт kmap/uaccess: вызывать в cli-контексте.** Окна одни на CPU;
критические секции IPC/сисколлов/proc держат прерывания выключенными на время
копирования (микросекунды).

## uaccess — безопасная юзер-память (core 2.0+)

- ua_valid(va, len): диапазон строго внутри [16MB, 2GB)
- ua_copy_from / ua_copy_to: постранично через kmap, отказ на незамапленном
- ua_copy_str: строки с капом + NUL
Сисколлы и IPC идут только через uaccess. Юзер больше не может словить
ядро на #PF в ring0: вместо паники — честный -1 из syscall.

## IPC — синхронный rendezvous

Сообщение 64 байта {from_id, type, data[56]}. Доставка ровно один раз:
из пространства отправителя в пространство получателя через uaccess
(никаких CR3-свитчей, TLB не страдает). Если получатель не ждёт —
отправитель FIFO-паркуется в его wq (wq_head/wq_tail в struct task).

- recv / recv_from(expect): выборочный приём по полному pid; recv_expect
  одновременно гейтит чужих отправителей
- exec_gate: пока задача тянет бинарь через kernel-side fs, чужие сообщения
  ей не доставляются
- IRQ = сообщения: irq_handler доставляет MSG_IRQ ВЛАДЕЛЬЦУ линии
  (irq_register, владелец = полный pid); промах -> irq_pending счётчик,
  разбирается владельцем при следующем recv
- MSG_DIED: при смерти задачи ipc_flush_task будит её ожидателей
  (BLOCKED_SEND -> RUNNING) И тех, кто ждал именно её (recv_expect == pid):
  получатель получает служебный MSG_DIED вместо вечного сна. fs_fetch на нём
  возвращает -ESRCH -> exec падает красиво, зомби-процессов нет.

## Сисколлы

1 WRITE, 4 CLEAR, 5 SEND, 6 RECV, 7 SEND_NB, 8 IRQ_REG, 9 IOPORT_ALLOW,
10 TASKS, 11 MEMFREE, 12 FORK, 13 EXEC, 14 EXIT, 15 WAIT, 16 GETPID, 17 KILL.
Все юзер-указатели валидируются (строки WRITE — чанками по 64B, кап 1KB;
TASKS — сбор в ядерный staging + ua_copy_to).

## fork / exec / exit / wait / kill

- fork: новый PD, поблочный клон user-половины, ядерный стек копией кадра,
  EAX ребёнка = 0, parent = полный pid родителя
- exec: ua-чтение path/args -> exec_lock (один exec за раз, staging 70KB
  защищён) -> fs_fetch (с MSG_DIED-страховкой) -> ELF-валидация -> новый PD,
  старый освобождается, кадр переписывается. exec_gate прикрывает окно загрузки
- exit: ipc_flush_task, освобождение user-страниц, ZOMBIE, будим родителя
  (wait pid == точный или WNOHANG -2 / любой -1)
- kill: запрет по слотам 1..5 нулевого поколения (серверы), запрет убивать
  предков, decode slot|gen + сверка поколения (stale pid = ESRCH),
  самоубийство = exit(137)

## Безопасность ELF (core 2.0+)

elf_map валидирует КАЖДЫЙ вход: сигнатура, ELFCLASS32, little-endian,
ET_EXEC, EM_386, число phdr <= 32, размер phdr-таблицы, per-PT_LOAD:
filesz <= memsz, границы в файле (u64), memsz <= 64MB, p_vaddr в юзер-диапазоне,
p_vaddr page-aligned, p_offset page-aligned, entry внутри какого-либо PT_LOAD.
Малварный ELF больше не пишет в ядерные PT: paging_map_user видит только
адреса из юзер-диапазона.

## Исключения, TSS и double fault (core 2.1+)

- исключения идут через два семейства stub'ов (с error-code и без): макросы
  EXCE/EXCN в exceptions.asm, общий путь exc_common передаёт в panic
  (vec, err, cr2, eip); panic печатает ИМЯ вектора (#UD, #GP, #PF...)
- вектор 8 (double fault) = task gate: IDT[8] = 0x85, селектор 0x30 ->
  отдельная df_tss в GDT[6] со своим стеком df_stack (4KB, .bss, aligned).
  Мёртвый стек ядра больше не превращается в triple fault: железо само
  переключается в DF-таску и печатает DOUBLE FAULT
- esp0 начальный и df_stack — статические массивы в .bss (до 2.1 esp0 указывал
  на НЕ зарезервированную страницу 0x200000)
- canary: дно каждого kstack помечено KSTACK_CANARY 0x4D494348;
  scheduler проверяет при каждом переключении -> PANIC KERNEL STACK OVERFLOW

## Права: is_driver (core 2.1+, временная мера до capability)

SYS_IOPORT_ALLOW и SYS_IRQ_REG требуют флага is_driver в struct task.
Флаг ставится ТОЛЬКО elf_load модулей, чьё имя (basename без расширения) в
белом списке: ata, kbd, pci. fork/exec флаг сбрасывают: при fork ребёнок
получает iomap=0 и is_driver=0 (порты НЕ наследуются), при exec карта
портов освобождается. Обычный elf делает syscall(9,...) -> EPERM,
inb(0x60) -> #GP. IRQ после смерти владельца освобождается
(irq_release_owner из exit/kill) и доступен новому владельцу.

## PMM: правило владения страницей (core 2.1+)

pmm_alloc_page НЕ зануляет страницы выше 16MB. Контракт: потребитель обязан
инициализировать страницу целиком. elf_map/paging_clone_user пишут страницу
полностью; юзер-стеки elf_load зануляются явно через kmap. RAM выше 512MB:
честный WARNING в serial (биткарта покрывает 512MB); pmm_reserve за границей
биткарты тоже печатает WARNING вместо молчаливого no-op.

## ELF: коды и флаги (core 2.1+)

elf_map возвращает адресные коды: -1 формат, -2 OOM, -3 type/machine,
-4 phdr, -5 границы сегмента, -6 vaddr, -7 congruence (p_offset == p_vaddr
mod 4096, требование ELF-спеки), -8 entry вне PT_LOAD. kernel.c печатает
каждый фейл модуля в serial. Сегменты без PF_W мапятся read-only
(USER_RO 0x4): запись в свою .rodata -> #PF, паника с vec=14.

## IPC: посмертная доставка (core 2.1+)

- ipc_send: все чтения чужого state/id и enqueue в wq теперь в ОДНОМ
  intr_off-регионе: окна "умер между проверкой и блокировкой" больше нет
- ipc_send после пробуждения возвращает s->send_result: 0 при доставке,
  ESRCH если получатель умер раньше (ставит ipc_flush_task). Честный
  ответ вместо фальшивого успеха
- recv_from(expect): если ожидаемый УЖЕ мёртв/освобождён на момент входа —
  синтезируется MSG_DIED синхронно (в том же intr-регионе, атомарно с блоком).
  Окно "died-нотификация ушла до нашего входа в recv" закрыто
- xlat_msg — стековая переменная в каждой функции (инвариант cli-контекста
  больше не носит глобального скрытого состояния)
- ESRCH/EPERM/... в protos.h — отрицательные константы; в коде нигде нет
  "-E***", класс багов "забыл минус" уничтожен
- зомби сразу обнуляет recv_buf/recv_expect/pending_msg/next/wait_pid
- непрочитанные IRQ не сгорают: irq_poll_pending декрементит счётчик,
  а не зануляет (два быстрых IRQ -> два MSG_IRQ)

## Исправлено в Core 2.0 "Polished" (аудит-пасс)

1. ELF p_vaddr без валидации -> USER мог переписать ядерные PT. Закрыто.
2. Сисколлы без проверки юзер-указателей -> паника из юзерленда. Закрыто (uaccess).
3. Гонка на exec_stage буфере (2 exec'а) -> exec_lock.
4. Вечный сон получателя при смерти ожидаемого сервера -> MSG_DIED.
5. CR3-свитч на каждое IPC-сообщение -> копирование через kmap-окна.
6. CR3 reload на каждом тике -> только при смене PD.
7. fork: побайтовое клонирование под cli -> dword-копия.
8. PID-reuse ABA -> поколения (gen<<16|slot).
9. intr_off/intr_on x3 -> irq.h. 10. Магия -> KFR_*/USER_*/константы.
11. set_name x3 -> task_set_name. 12. GRUB/multiboot из ядра -> снесён.

## Честный долг (знаем и планируем)

- fork: copy-on-write вместо полного клона
- SMP (AP x86_64 эра), тогда kmap-окна станут per-cpu
- таймауты на ipc_send (сейчас вечный сон при дедлок-цикле; лечится kill'ом)
- kbd typeahead-буфер (пока форграунд-процесс не готов — ввод не буферизуется)
- cap на SYS_WRITE сделать потоковым (сейчас 1KB за вызов)
- W^X по-настоящему: юзер .text read-only после загрузки есть (2.1), но NX-бита
  на i386 без PAE нет — либо PAE, либо документируем ограничение
- guard-страницы kstack: пока ловит canary, а не #PF (нужен уход от identity-маппинга)
- FPU/SSE политика: сейчас fail-closed (CR4.OSFXSR не поднят -> любой SSE = #UD,
  ядро собрано с -mno-sse*, objdump подтверждает 0 xmm). Ленивый fxsave/#NM —
  возможный апгрейд, но политика запрета тоже легитимна
- capability-модель вместо is_driver-белого списка и PID-адресации (seL4-путь)
- PMM: O(1) аллокация (buddy/free-list) вместо скана биткарты
- формальные инструменты: CBMC/Frama-C на pmm/ipc/uaccess, AFL на ELF-парсер
- автотесты: make test уже гоняет boot-сценарий (tests/boot_test.py);
  CI на каждый push — следующий шаг
